from django.apps import AppConfig


class EncuestasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EncuestasApp'
