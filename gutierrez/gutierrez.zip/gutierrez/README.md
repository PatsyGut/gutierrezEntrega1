#Entrega #1

---
La aplicación EncuestasApp está implementada para poder llenar valoraciones de cursos
Los modelos utilizados son:
1. **Modalidad:** Para almacenar información de las modalidades de los cursos
2. **Curso:** Información general del curso
3. **Encuesta:** Valoración del curso

La base de datos está con información referencial llena.
Se ha creado un menú lateral con los enlaces a la búsqueda y formularios